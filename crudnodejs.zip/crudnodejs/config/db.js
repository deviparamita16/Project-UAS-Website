const sequelize = require("sequelize");

const db =new sequelize("crudnodejs1", "root", "", {
    dialect: "mysql"
});

db.sync({});

module.exports =  db;